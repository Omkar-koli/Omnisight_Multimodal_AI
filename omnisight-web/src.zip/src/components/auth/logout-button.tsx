"use client";

import { signOut } from "next-auth/react";

export function LogoutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/login" })}
      className="rounded-lg border px-3 py-2 text-sm hover:bg-muted"
    >
      Sign out
    </button>
  );
}