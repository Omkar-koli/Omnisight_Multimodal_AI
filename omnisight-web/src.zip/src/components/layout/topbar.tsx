import { auth } from "@/auth";
import { LogoutButton } from "@/components/auth/logout-button";

export async function Topbar() {
  const session = await auth();

  return (
    <header className="flex h-16 items-center justify-between border-b px-4 md:px-6">
      <div>
        <h1 className="text-lg font-semibold">Enterprise Inventory Intelligence</h1>
        <p className="text-sm text-muted-foreground">
          Multimodal restocking decisions powered by rules, retrieval, and AI.
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-right text-sm">
          <div className="font-medium">{session?.user?.name || "Unknown user"}</div>
          <div className="text-muted-foreground">
            {session?.user?.email || ""} · {session?.user?.role || "viewer"}
          </div>
        </div>
        <LogoutButton />
      </div>
    </header>
  );
}