import Link from "next/link";
import { Boxes, LayoutDashboard, PackageSearch, ClipboardList, Activity, RefreshCcw } from "lucide-react";

export function Sidebar() {
  return (
    <aside className="hidden border-r bg-muted/30 lg:block">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <Boxes className="h-5 w-5" />
        <span className="font-semibold">OmniSight</span>
      </div>

      <nav className="space-y-2 p-4">
        <Link
          href="/"
          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"
        >
          <LayoutDashboard className="h-4 w-4" />
          Dashboard
        </Link>

        <Link
          href="/products"
          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"
        >
          <PackageSearch className="h-4 w-4" />
          Products
        </Link>
        <Link
          href="/monitoring"
          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"
        >
          <Activity className="h-4 w-4" />
          Monitoring
        </Link>

        <Link
          href="/reviews"
          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"
        >
          <ClipboardList className="h-4 w-4" />
          Reviews
        </Link>
        <Link
          href="/jobs"
          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"
        >
          <RefreshCcw className="h-4 w-4" />
          Jobs
        </Link>
      </nav>
    </aside>
  );
}