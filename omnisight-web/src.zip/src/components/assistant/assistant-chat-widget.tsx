"use client";

import { useMemo, useState } from "react";
import { useParams, usePathname } from "next/navigation";
import { sendAssistantChat } from "@/lib/api";
import type {
  AssistantChatMessage,
  AssistantChatResponse,
} from "@/lib/types";

import { AssistantResponse } from "@/components/assistant/assistant-response";

function getPageContext(pathname: string, productId?: string) {
  if (pathname.startsWith("/products/") && productId) {
    return "product_detail" as const;
  }
  if (pathname.startsWith("/products")) {
    return "products" as const;
  }
  if (pathname.startsWith("/monitoring")) {
    return "monitoring" as const;
  }
  return "global" as const;
}

function getStarterPrompts(
  pageContext: "products" | "monitoring" | "product_detail" | "global"
) {
  if (pageContext === "products") {
    return [
      "What is trending right now?",
      "What do you think will trend next?",
      "Which category needs the most attention?",
      "Which products are overstocked?",
    ];
  }

  if (pageContext === "monitoring") {
    return [
      "Which products need attention first?",
      "What is trending right now?",
      "What do you think will trend next?",
      "Which products are overstocked?",
    ];
  }

  if (pageContext === "product_detail") {
    return [
      "Summarize this product for me.",
      "Why was this product flagged?",
      "What is the biggest risk for this product?",
      "Should I monitor this product closely?",
    ];
  }

  return [
    "What is trending right now?",
    "What do you think will trend next?",
    "Which products need attention first?",
  ];
}

function normalizeAssistantText(text: string) {
  if (!text) return "";

  return text
    .replace(/\r\n/g, "\n")
    .replace(/(\d+\.\s)/g, "\n$1") // put numbered items on new lines
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function renderInlineBold(text: string) {
  const parts = text.split(/(\*\*.*?\*\*)/g);

  return parts.map((part, index) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={index} className="font-semibold text-foreground">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <span key={index}>{part}</span>;
  });
}

function renderAssistantContent(content: string) {
  const normalized = normalizeAssistantText(content);
  const lines = normalized
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);

  return (
    <div className="space-y-3 text-sm leading-7 text-foreground">
      {lines.map((line, idx) => {
        const numbered = line.match(/^(\d+)\.\s+(.*)$/);
        const bullet = line.match(/^[-•]\s+(.*)$/);

        if (numbered) {
          return (
            <div key={idx} className="flex items-start gap-3 rounded-xl bg-muted/60 p-3">
              <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs font-semibold">
                {numbered[1]}
              </div>
              <div className="flex-1 break-words">{renderInlineBold(numbered[2])}</div>
            </div>
          );
        }

        if (bullet) {
          return (
            <div key={idx} className="flex items-start gap-2">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-foreground/60" />
              <div className="break-words">{renderInlineBold(bullet[1])}</div>
            </div>
          );
        }

        return (
          <p key={idx} className="break-words">
            {renderInlineBold(line)}
          </p>
        );
      })}
    </div>
  );
}

export function AssistantChatWidget() {
  const pathname = usePathname();
  const params = useParams<{ productId?: string }>();
  const productId =
    typeof params?.productId === "string" ? params.productId : undefined;

  const pageContext = useMemo(
    () => getPageContext(pathname, productId),
    [pathname, productId]
  );

  const isVisible =
    pageContext === "products" ||
    pageContext === "monitoring" ||
    pageContext === "product_detail";

  const starterPrompts = useMemo(
    () => getStarterPrompts(pageContext),
    [pageContext]
  );

  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<AssistantChatMessage[]>([
    {
      role: "assistant",
      content:
        "Hi, I’m the OmniSight assistant.\n\nAsk me what is trending right now, what may trend next, which products are overstocked, or which products need attention.",
    },
  ]);
  const [suggestions, setSuggestions] = useState<string[]>(starterPrompts);
  const [isLoading, setIsLoading] = useState(false);
  const [referencedProductIds, setReferencedProductIds] = useState<string[]>([]);

  if (!isVisible) {
    return null;
  }

  async function handleSend(messageText?: string) {
    const text = (messageText ?? input).trim();
    if (!text || isLoading) return;

    const nextUserMessage: AssistantChatMessage = {
      role: "user",
      content: text,
    };

    setMessages((prev) => [...prev, nextUserMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const res: AssistantChatResponse = await sendAssistantChat({
        message: text,
        page_context: pageContext,
        product_id: productId || "",
      });

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: res.answer,
        },
      ]);

      setSuggestions(res.suggestions?.length ? res.suggestions : starterPrompts);
      setReferencedProductIds(res.referenced_product_ids ?? []);
    } catch (error: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            error?.message ||
            "Sorry, I could not process that question right now.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="fixed bottom-5 right-5 z-50 rounded-full border bg-background px-4 py-3 text-sm font-medium shadow-lg transition hover:bg-muted"
      >
        {isOpen ? "Close Assistant" : "Open Assistant"}
      </button>

      {isOpen ? (
        <div className="fixed bottom-20 right-5 z-50 flex h-[78vh] w-[460px] max-w-[calc(100vw-1.5rem)] flex-col overflow-hidden rounded-2xl border bg-background shadow-2xl">
          <div className="border-b px-5 py-4">
            <div className="text-base font-semibold">OmniSight Assistant</div>
            <div className="mt-1 text-sm text-muted-foreground">
              Ask about trending products, likely future trends, risk, and product signals.
            </div>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
            {messages.map((message, index) => (
                  <div
                    key={`${message.role}-${index}`}
                    className={`max-w-[95%] rounded-2xl px-3 py-3 text-sm ${
                      message.role === "user"
                        ? "ml-auto bg-foreground text-background"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      <AssistantResponse content={message.content} />
                    ) : (
                      <div className="whitespace-pre-wrap leading-6">{message.content}</div>
                    )}
                  </div>
                ))}

            {isLoading ? (
              <div className="max-w-[92%] rounded-2xl bg-muted px-4 py-3 text-sm text-foreground">
                Thinking...
              </div>
            ) : null}
          </div>

          {referencedProductIds.length > 0 ? (
            <div className="border-t px-4 py-3">
              <div className="mb-2 text-xs font-medium text-muted-foreground">
                Referenced Products
              </div>
              <div className="flex flex-wrap gap-2">
                {referencedProductIds.slice(0, 6).map((id) => (
                  <a
                    key={id}
                    href={`/products/${id}`}
                    className="rounded-full border px-2.5 py-1 text-xs hover:bg-muted"
                  >
                    {id}
                  </a>
                ))}
              </div>
            </div>
          ) : null}

          <div className="border-t px-4 py-3">
            <div className="mb-2 text-xs font-medium text-muted-foreground">
              Quick prompts
            </div>

            <div className="mb-3 flex flex-wrap gap-2">
              {suggestions.slice(0, 4).map((suggestion, index) => (
                <button
                  key={`${suggestion}-${index}`}
                  type="button"
                  onClick={() => handleSend(suggestion)}
                  className="rounded-full border px-3 py-1.5 text-xs hover:bg-muted"
                  disabled={isLoading}
                >
                  {suggestion}
                </button>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Ask about products, trends, or risks..."
                className="flex-1 rounded-xl border bg-background px-3 py-2 text-sm outline-none"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="rounded-xl border px-4 py-2 text-sm font-medium transition hover:bg-muted disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}